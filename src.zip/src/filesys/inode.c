#include "filesys/inode.h"
#include <list.h>
#include <debug.h>
#include <round.h>
#include <string.h>
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "filesys/cache.h"
#include "threads/malloc.h"

/* Identifies an inode. */
#define INODE_MAGIC 0x494e4f44

/* Returns the number of sectors to allocate for an inode SIZE
   bytes long. */
static inline size_t
bytes_to_sectors (off_t size)
{
  return DIV_ROUND_UP (size, DISK_SECTOR_SIZE);
}

/* Returns the disk sector that contains byte offset POS within
   INODE.
   Returns -1 if INODE does not contain data for a byte at offset
   POS. */
static disk_sector_t
byte_to_sector (const struct inode *inode, off_t pos) 
{
  ASSERT (inode != NULL);
  if (pos < inode->data.length)
  {
    //return inode->data.start + pos / DISK_SECTOR_SIZE;
    int double_indirect = MAX_DIRECT*MAX_INDIRECT;
    int single_indirect = MAX_DIRECT;

    int double_idx = (pos / DISK_SECTOR_SIZE) / double_indirect;
    struct inode_disk *double_inode;
    double_inode = calloc (1, sizeof (struct inode_disk));
    read_buff (inode->data.start[double_idx], double_inode, 0, DISK_SECTOR_SIZE);

    int single_idx = (pos / DISK_SECTOR_SIZE) % double_indirect;
    int direct_idx = single_idx % single_indirect;
    single_idx = single_idx / single_indirect;
    struct inode_disk *single_inode;
    single_inode = calloc (1, sizeof (struct inode_disk));
    read_buff (double_inode->start[single_idx], single_inode, 0, DISK_SECTOR_SIZE);

    disk_sector_t return_value = single_inode->start[direct_idx];
    free (single_inode);
    free (double_inode);

    return return_value;
  }
  else
    return -1;
}

/* List of open inodes, so that opening a single inode twice
   returns the same `struct inode'. */
static struct list open_inodes;

/* Initializes the inode module. */
void
inode_init (void) 
{
  list_init (&open_inodes);
}

/* Initializes an inode with LENGTH bytes of data and
   writes the new inode to sector SECTOR on the file system
   disk.
   Returns true if successful.
   Returns false if memory or disk allocation fails. */
bool
inode_create (disk_sector_t sector, off_t length, int depth, int is_dir)
{
  struct inode_disk *disk_inode = NULL;
  bool success = false;
  int i;

  ASSERT (length >= 0);

  /* If this assertion fails, the inode structure is not exactly
     one sector in size, and you should fix that. */
  ASSERT (sizeof *disk_inode == DISK_SECTOR_SIZE);

  disk_inode = calloc (1, sizeof *disk_inode);
  if (disk_inode != NULL)
    {
      size_t sectors = bytes_to_sectors (length);
      disk_inode->length = length;
      disk_inode->magic = INODE_MAGIC;
      disk_inode->depth = depth;
      disk_inode->is_dir = is_dir;

      if(disk_inode->depth == 0) // direct
      {
          disk_inode->num_sector = sectors;
          if(free_map_allocate(sectors, disk_inode->start))
          {
              write_buff(sector, disk_inode, 0, DISK_SECTOR_SIZE);
              if(sectors > 0)
              {
                  static char zeros[DISK_SECTOR_SIZE];

                  for(i=0; i<sectors; i++)
                  {
                      write_buff(disk_inode->start[i], zeros, 0, DISK_SECTOR_SIZE);
                  }
              }
              success = true;
          }
      }
      else
      {
          size_t indirect_sectors = 0;

          if(disk_inode->depth == LV1)
          {
              indirect_sectors = DIV_ROUND_UP(sectors, MAX_DIRECT);
          }
          else if(disk_inode->depth == LV2)
          {
              indirect_sectors = DIV_ROUND_UP(sectors, MAX_DIRECT * MAX_INDIRECT);
          }

          disk_inode->num_sector = indirect_sectors;

          if(free_map_allocate(indirect_sectors, disk_inode->start))
          {
              for(i=0; i<indirect_sectors; i++)
              {
                  size_t need_sectors = 0;
                  int div = 0;
                  if(i == indirect_sectors - 1) // 마지막 섹터면
                  {
                      div = depth == 1 ? MAX_DIRECT : MAX_DIRECT * MAX_INDIRECT;
                      need_sectors = sectors % div;
                      if (need_sectors == 0) need_sectors = div;
                  }
                  else
                  {
                      need_sectors = depth == 1 ? MAX_DIRECT : MAX_DIRECT * MAX_INDIRECT;
                  }

                  bool created = inode_create(disk_inode->start[i], need_sectors * DISK_SECTOR_SIZE, depth-1, is_dir);
                  if(!created)
                  {
                      ASSERT(0);
                      int j;
                      for(j=0; j<i; j++)
                      {
                          inode_disk_remove(disk_inode->start[j]);
                      }
                      break;
                  }
              }

              write_buff(sector, disk_inode, 0, DISK_SECTOR_SIZE);
              success = true;
          }
      }

      // if(success)
      // {
      //     write_buff(sector, disk_inode, 0, DISK_SECTOR_SIZE);
      // }

      free (disk_inode);
    }
  return success;
}

/* Reads an inode from SECTOR
   and returns a `struct inode' that contains it.
   Returns a null pointer if memory allocation fails. */
struct inode *
inode_open (disk_sector_t sector) 
{
  struct list_elem *e;
  struct inode *inode;

  /* Check whether this inode is already open. */
  for (e = list_begin (&open_inodes); e != list_end (&open_inodes);
       e = list_next (e)) 
    {
      inode = list_entry (e, struct inode, elem);
      if (inode->sector == sector) 
        {
          inode_reopen (inode);
          return inode; 
        }
    }

  /* Allocate memory. */
  inode = malloc (sizeof *inode);
  if (inode == NULL)
    return NULL;

  /* Initialize. */
  list_push_front (&open_inodes, &inode->elem);
  inode->sector = sector;
  inode->open_cnt = 1;
  inode->deny_write_cnt = 0;
  inode->removed = false;
  read_buff(inode->sector, &inode->data, 0, DISK_SECTOR_SIZE);
  //disk_read (filesys_disk, inode->sector, &inode->data);
  return inode;
}

/* Reopens and returns INODE. */
struct inode *
inode_reopen (struct inode *inode)
{
  if (inode != NULL)
    inode->open_cnt++;
  return inode;
}

/* Returns INODE's inode number. */
disk_sector_t
inode_get_inumber (const struct inode *inode)
{
  return inode->sector;
}

/* Closes INODE and writes it to disk.
   If this was the last reference to INODE, frees its memory.
   If INODE was also a removed inode, frees its blocks. */
void
inode_close (struct inode *inode) 
{
  /* Ignore null pointer. */
  if (inode == NULL)
    return;

  /* Release resources if this was the last opener. */
  if (--inode->open_cnt == 0)
    {
      /* Remove from inode list and release lock. */
      list_remove (&inode->elem);
 
      /* Deallocate blocks if removed. */
      if (inode->removed) 
        {
          // free_map_release (inode->sector, 1);
          // free_map_release (inode->data.start,
          //                   bytes_to_sectors (inode->data.length)); 

          inode_disk_remove(inode->sector);
        }

      free (inode); 
    }
}

/* Marks INODE to be deleted when it is closed by the last caller who
   has it open. */
void
inode_remove (struct inode *inode) 
{
  ASSERT (inode != NULL);
  inode->removed = true;
}

void inode_disk_remove(disk_sector_t sector)
{
    struct inode_disk *di = calloc(1, sizeof(struct inode_disk));
    read_buff(sector, di, 0, DISK_SECTOR_SIZE);
    size_t sectors = di->num_sector;

    // free_map_release(&sector, 1);

    if(di->depth == 0) // direct inode_disk
    {
        free_map_release(di->start, sectors);
    }
    else
    {
        int i;
        for(i=0; i<sectors; i++)
        {
            inode_disk_remove(di->start[i]);
        }
    }

    // free(di);
    free_map_release(&sector, 1);
}

/* Reads SIZE bytes from INODE into BUFFER, starting at position OFFSET.
   Returns the number of bytes actually read, which may be less
   than SIZE if an error occurs or end of file is reached. */
off_t
inode_read_at (struct inode *inode, void *buffer_, off_t size, off_t offset) 
{
  uint8_t *buffer = buffer_;
  off_t bytes_read = 0;
  uint8_t *bounce = NULL;

  if (inode->data.length <= offset) return 0;

  while (size > 0) 
    {
      /* Disk sector to read, starting byte offset within sector. */
      disk_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % DISK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = DISK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually copy out of this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      read_buff(sector_idx, buffer + bytes_read, sector_ofs, chunk_size);
      // if (sector_ofs == 0 && chunk_size == DISK_SECTOR_SIZE) 
      //   {
          /* Read full sector directly into caller's buffer. */
      //     disk_read (filesys_disk, sector_idx, buffer + bytes_read); 
      //   }
      // else 
      //   {
          /* Read sector into bounce buffer, then partially copy
             into caller's buffer. */
          // if (bounce == NULL) 
          //   {
          //     bounce = malloc (DISK_SECTOR_SIZE);
          //     if (bounce == NULL)
          //       break;
          //   }
        //   disk_read (filesys_disk, sector_idx, bounce);
        //   memcpy (buffer + bytes_read, bounce + sector_ofs, chunk_size);
        // }
      
      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_read += chunk_size;
    }
  // free (bounce);

  return bytes_read;
}

/* Writes SIZE bytes from BUFFER into INODE, starting at OFFSET.
   Returns the number of bytes actually written, which may be
   less than SIZE if end of file is reached or an error occurs.
   (Normally a write at end of file would extend the inode, but
   growth is not yet implemented.) */
off_t
inode_write_at (struct inode *inode, const void *buffer_, off_t size,
                off_t offset) 
{
  const uint8_t *buffer = buffer_;
  off_t bytes_written = 0;
  uint8_t *bounce = NULL;

  if (inode->deny_write_cnt)
    return 0;

  if(!inode_expand(&inode->data, inode->sector, offset + size, LV2, inode->data.is_dir)) return 0;

  while (size > 0) 
    {
      /* Sector to write, starting byte offset within sector. */
      disk_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % DISK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = DISK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually write into this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      write_buff(sector_idx, buffer + bytes_written, sector_ofs, chunk_size);
      // if (sector_ofs == 0 && chunk_size == DISK_SECTOR_SIZE) 
      //   {
          /* Write full sector directly to disk. */
      //     disk_write (filesys_disk, sector_idx, buffer + bytes_written); 
      //   }
      // else 
      //   {
      //     /* We need a bounce buffer. */
      //     if (bounce == NULL) 
      //       {
      //         bounce = malloc (DISK_SECTOR_SIZE);
      //         if (bounce == NULL)
      //           break;
      //       }

          /* If the sector contains data before or after the chunk
             we're writing, then we need to read in the sector
             first.  Otherwise we start with a sector of all zeros. */
        //   if (sector_ofs > 0 || chunk_size < sector_left) 
        //     disk_read (filesys_disk, sector_idx, bounce);
        //   else
        //     memset (bounce, 0, DISK_SECTOR_SIZE);
        //   memcpy (bounce + sector_ofs, buffer + bytes_written, chunk_size);
        //   disk_write (filesys_disk, sector_idx, bounce); 
        // }

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_written += chunk_size;
    }
  // free (bounce);

  return bytes_written;
}

bool inode_expand(struct inode_disk *disk_inode, disk_sector_t sector, off_t length, int depth, int is_dir)
{
    if(length > disk_inode->length)
    {
        bool success = true;
        int i;
        ASSERT (length >= 0);

        /* If this assertion fails, the inode structure is not exactly
        one sector in size, and you should fix that. */
        ASSERT (sizeof *disk_inode == DISK_SECTOR_SIZE);
        ASSERT (disk_inode != NULL);

        size_t sectors = bytes_to_sectors (length); // bytes 길이를 필요한 sector 수로 바꿔준다.
        size_t old_sectors = disk_inode->num_sector;
        disk_inode->length = length;
        disk_inode->depth = depth;
        disk_inode->is_dir = is_dir;

        int more_sectors = 0;

        if(disk_inode->depth == 0) // direct
        {
            disk_inode->num_sector = sectors;
            more_sectors = sectors - old_sectors;
            if(free_map_allocate(more_sectors, disk_inode->start + old_sectors))
            {
                write_buff(sector, disk_inode, 0, DISK_SECTOR_SIZE);
                if(more_sectors > 0)
                {
                    static char zeros[DISK_SECTOR_SIZE];
                    int i;

                    for(i=old_sectors; i<sectors; i++)
                    {
                        write_buff(disk_inode->start[i], zeros, 0, DISK_SECTOR_SIZE);
                    }
                }
                success = true;
            }
            else success = false;
        }
        else
        {
            size_t indirect_sectors = 0;
            size_t old_indirect_sectors = 0;
            size_t more_sector_size = sectors - old_sectors; // 현재 끝부분 섹터에서 실제로 늘려야 하는 하위 섹터의 개수를 의미.
            // 205개에서 232개까지 sector를 늘려야 한다면, more_sector_size는 27개.
            // 205개에서 313개까지 sector를 늘려야 한다면, more_sector_size는 100개. (마지막 섹터는 300개까지만 늘어날 수 있으므로)

            if(disk_inode->depth == 1)
            {
                indirect_sectors = DIV_ROUND_UP(sectors, MAX_DIRECT);
                old_indirect_sectors = old_sectors;

                more_sector_size = sectors - MAX_DIRECT*(old_indirect_sectors-1);

                if(more_sector_size > MAX_DIRECT) more_sector_size = MAX_DIRECT;
            }
            else if(disk_inode->depth == 2)
            {
                indirect_sectors = DIV_ROUND_UP(sectors, MAX_DIRECT * MAX_INDIRECT);
                old_indirect_sectors = old_sectors;

                more_sector_size = sectors - MAX_INDIRECT*MAX_DIRECT*(old_indirect_sectors-1);

                if(more_sector_size > MAX_DIRECT * MAX_INDIRECT) more_sector_size = MAX_DIRECT * MAX_INDIRECT;
            }

            disk_inode->num_sector = indirect_sectors;

            more_sectors = indirect_sectors - old_indirect_sectors;// 더 늘려야 하는 섹터 수

            if(old_indirect_sectors > 0) // 마지막 섹터에 있는 데이터를 복사한 후, expand된 부분에는 0 넣어준다.
            {
                struct inode_disk *more_di = calloc(1, sizeof(struct inode_disk));
                // old_indirect_sectors-1번째 섹터를 읽은 후에, expand해준다.
                read_buff(disk_inode->start[old_indirect_sectors-1], more_di, 0, DISK_SECTOR_SIZE);
                if (!inode_expand(more_di, disk_inode->start[old_indirect_sectors-1], more_sector_size * DISK_SECTOR_SIZE, depth - 1, is_dir))
                  success = false;

                free(more_di);
            }

            if (success)
            {
              if(free_map_allocate(more_sectors, disk_inode->start + old_indirect_sectors))
              {
                  write_buff (sector, disk_inode, 0, DISK_SECTOR_SIZE);
                  for(i=old_indirect_sectors; i<indirect_sectors; i++)
                  {
                      size_t need_sectors = 0;
                      int div = 0;
                      if(i == indirect_sectors - 1) // 마지막 섹터면
                      {
                          div = depth == 1 ? MAX_DIRECT : MAX_DIRECT * MAX_INDIRECT;
                          need_sectors = sectors % div;

                          if (need_sectors == 0) need_sectors = div;
                      }
                      else
                      {
                          need_sectors = depth == 1 ? MAX_DIRECT : MAX_DIRECT * MAX_INDIRECT;
                      }

                      success = inode_create(disk_inode->start[i], need_sectors * DISK_SECTOR_SIZE, depth-1, is_dir);
                  }
              }
              else success = false;
            }
        }

        if(success)
        {
            // inode 정보 변경 내역을 저장한다.
            //write_buff(sector, disk_inode, 0, DISK_SECTOR_SIZE);        
        }

        return success;
    }
    else return true;
}

/* Disables writes to INODE.
   May be called at most once per inode opener. */
void
inode_deny_write (struct inode *inode) 
{
  inode->deny_write_cnt++;
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
}

/* Re-enables writes to INODE.
   Must be called once by each inode opener who has called
   inode_deny_write() on the inode, before closing the inode. */
void
inode_allow_write (struct inode *inode) 
{
  ASSERT (inode->deny_write_cnt > 0);
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
  inode->deny_write_cnt--;
}

/* Returns the length, in bytes, of INODE's data. */
off_t
inode_length (const struct inode *inode)
{
  return inode->data.length;
}
